Edgewall Documentation Utilities
================================

This repository contains distutils commands for generating offline documentation
from reStructuredText files and Python source code. These tools are shared among
a couple of different Edgewall projects to ensure common style and
functionality.
