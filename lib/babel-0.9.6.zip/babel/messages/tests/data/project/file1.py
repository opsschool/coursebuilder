# -*- coding: utf-8 -*-
# file1.py for tests

from gettext import gettext as _
def foo():
    # TRANSLATOR: This will be a translator coment,
    # that will include several lines
    print _('bar')
